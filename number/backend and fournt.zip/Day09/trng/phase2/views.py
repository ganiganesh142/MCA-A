from django.shortcuts import HttpResponse
from django.http import HttpResponse
from django.template import loader
def place(request):
    temp=loader.get_template('gani.html')
    return HttpResponse(temp.render())
def day16(request):
    temp=loader.get_template('Hr.html')
    return HttpResponse(temp.render())
def day17(request):
    temp=loader.get_template('M.html')
    return HttpResponse(temp.render())
def day18(request):
    temp=loader.get_template('s.html')
    return HttpResponse(temp.render())
def day19(request):
    temp=loader.get_template('Hr.html')
    return HttpResponse(temp.render())
def day20(request):
    temp=loader.get_template('M.html')
    return HttpResponse(temp.render())
def day21(request):
    temp=loader.get_template('s.html')
    return HttpResponse(temp.render())
def day22(request):
    temp=loader.get_template('Hr.html')
    return HttpResponse(temp.render())
def day23(request):
    temp=loader.get_template('M.html')
    return HttpResponse(temp.render())
def day24(request):
    temp=loader.get_template('s.html')
    return HttpResponse(temp.render())
def day25(request):
    temp=loader.get_template('Hr.html')
    return HttpResponse(temp.render())
def day26(request):
    temp=loader.get_template('M.html')
    return HttpResponse(temp.render())
def day27(request):
    temp=loader.get_template('s.html')
    return HttpResponse(temp.render())
def day28(request):
    temp=loader.get_template('Hr.html')
    return HttpResponse(temp.render())
def day29(request):
    temp=loader.get_template('M.html')
    return HttpResponse(temp.render())
def day30(request):
    temp=loader.get_template('s.html')
    return HttpResponse(temp.render())



# Create your views here.
