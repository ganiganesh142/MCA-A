from django.contrib import admin
from .models import FacultyModel
admin.site.register(FacultyModel)

# Register your models here.
