from django.apps import AppConfig


class TnConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'tn'
