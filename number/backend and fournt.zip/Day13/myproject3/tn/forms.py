from django.forms import fields  
from .models import EmployeeModel 
from .models import studentModel 
from django import forms  
class EmployeeForm(forms.ModelForm):  
    class Meta:  
        model = EmployeeModel  
        fields = '__all__' 
class studentForm(forms.ModelForm):  
    class Meta:  
        model = studentModel  
        fields = '__all__' 