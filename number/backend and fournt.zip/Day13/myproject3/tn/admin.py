from django.contrib import admin
from .models import studentModel
from .models import employeeModel
admin.site.register(studentModel)
admin.site.register(employeeModel)