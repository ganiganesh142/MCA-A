from django.urls import path
from. import views
urlpatterns= [
	path('sem1/',views.sem1, name='sem1'),
]