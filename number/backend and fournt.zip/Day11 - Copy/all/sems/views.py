from django.http import HttpsResponse
def sem1(request):
    return HttpResponse("sems")

# Create your views here.
