from django.shortcuts import render
def index(request):
    return render(request,'sum.html')

# Create your views here.
